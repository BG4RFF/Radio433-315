Note: 
- The I2C address of the I2C LCD Shield by catalex team is 0x38.

- The I2C address of I2C 1602 LCD module is 0x27(default) or 0x3F. 